import React from 'react';

export default () => (
	<div>
	<div id="slide1">PRODUTO 1</div>
	<div id="slide2">PRODUTO 2</div>
	</div>
);
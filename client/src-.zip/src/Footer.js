import React from 'react';

export default () => (
	<div>
		&copy; 2018 - MadeiraMadeira - Todos os direitos reservados.
	</div>
);
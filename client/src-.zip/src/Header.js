import React from 'react';

export default () => (
	<div>
		<div id="logo">MadeiraMadeira</div>
		<div id="search"><input type="search"/></div>
		<div id="chat">Chat</div>
		<div id="login">Login</div>
	</div>
);
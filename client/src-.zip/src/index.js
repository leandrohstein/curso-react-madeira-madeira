import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route } from 'react-router-dom';

import Home from './Home';
import Product from './Product';

const Routes = () => (
	<Router>
		<div>
			<Route path="/" component={Home} exact/>
			<Route path="/produto" component={Product} title="Cama Casal"/>
		</div>
	</Router>
);

ReactDOM.render(<Routes />, document.getElementById('root'));
